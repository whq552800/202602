# Revision v2 machine-readable source data

This package separates reader-facing supplementary tables from machine-readable source tables.
The current manuscript figures and tables are supported by the 2000-2023 benchmark/profile tables and the Figure 1-4 source workbook.
Historical 1990-2023 benchmark files from earlier analysis are not used to redefine the revision v2 profile counts unless explicitly noted.

Definitions: high observed is the year-specific upper-tertile observed under-5 LRI incidence; high excess is positive benchmark-relative excess in the year-specific upper-tertile excess range. Profiles are Double-high, Structural high, Excess-only and Neither.
Contextual domains are peer-relative descriptive lag domains. Positive adverse z indicates worse-than-same-year-SDI-peer context; delta adverse z below zero indicates catch-up, and above zero indicates contextual lag.
Contextual domains are post-classification, peer-relative profile variables. They summarise contextual lag or catch-up relative to same-year SDI peers and are not included in the expected-burden model.

Files are UTF-8 with BOM CSV where applicable, plus an XLSX workbook for figure source data.